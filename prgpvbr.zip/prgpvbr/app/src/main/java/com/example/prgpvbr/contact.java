package com.example.prgpvbr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class contact extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
    }

    public  void openinst(View view){

        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/christ_university_bangalore/"));
        startActivity(i);

    }
    public  void openfb(View view){

        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/www.christuniversity.in/?modal=admin_todo_tour"));
        startActivity(i);

    }
    public  void openytube(View view){

        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/thechristuniversity"));
        startActivity(i);

    }
}